<?php 
$primary_table_id_val = $_POST['primary_table_id_val'];
$table_name = $_POST['table_name'];
$primary_table_id_name = $_POST['primary_table_id_name'];
// echo $table_name.'<br>';
// echo $primary_table_id;
// die;
?>
        <form action="Ajax/usersAjax.php" id="delete_form" onsubmit="return validateUsersForm();" method="post">
          <div class="modal-body">
              <h4 class="modal-title">Do u want to confirm to delete it?</h4>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="primary_table_id_val" class="user_id" id="primary_table_id" value="<?php echo $primary_table_id_val;?>">
              <input type="hidden" name="table_name" class="user_id" id="table_name" value="<?php echo $table_name;?>">
              <input type="hidden" name="primary_table_id_name" class="user_id" id="primary_table_id_name" value="<?php echo $primary_table_id_name;?>">
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-outline-light" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-outline-light" onclick="commonDelete();">Confirm</button>
            </div>
        </form>
            
         
          
       