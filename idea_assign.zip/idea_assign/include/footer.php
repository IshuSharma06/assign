<div class="modal fade" id="commonModal">
        <div class="modal-dialog">
          <div class="modal-content bg-danger">
            <div class="modal-header">
              
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body" id="commonModalBody">
              
              
            </div>
            <!-- <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-outline-light" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-outline-light">Confirm</button>
            </div> -->
          </div>
          
        </div>
        <!-- /.modal-dialog -->
      </div>
<footer class="main-footer">
    Admin
  </footer>