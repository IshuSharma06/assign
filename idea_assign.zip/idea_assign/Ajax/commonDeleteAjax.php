<?php
require_once("../include/config.php");
try {
    if(isset($_POST['action']) && $_POST['action'] == "delete") {
        // pre($_POST);
        // die;
        $data = $_POST;
       
       
        $primary_table_id_val = "";
        $table_name  = "";
        $primary_table_id_name = "";
        
        

        $errors = 0;
        $msgArr = array();

        if(!isset($_POST['primary_table_id_val'])){
            $errors = $errors + 1;
            $msgArr[] = "Primary Table Id value data is missing";
        } else if(isset($_POST['primary_table_id_val']) && trim($_POST['primary_table_id_val']) == ""){
            $errors = $errors + 1;
            $msgArr[] = "Please enter primary table id value";
        } else {
            $primary_table_id_val = $_POST['primary_table_id_val'];
        }

        if(!isset($_POST['table_name'])){
            $errors = $errors + 1;
            $msgArr[] = "Table name data is missing";
        } else if(isset($_POST['table_name']) && trim($_POST['table_name']) == ""){
            $errors = $errors + 1;
            $msgArr[] = "Please enter table name";
        } else {
            $table_name = $_POST['table_name'];
        }

        if(!isset($_POST['primary_table_id_name'])){
            $errors = $errors + 1;
            $msgArr[] = "Primary Table Id name data is missing";
        } else if(isset($_POST['primary_table_id_name']) && trim($_POST['primary_table_id_name']) == ""){
            $errors = $errors + 1;
            $msgArr[] = "Please enter primary table id name";
        } else {
            $primary_table_id_name = $_POST['primary_table_id_name'];
        }

        

        if($errors > 0) {
            echo json_encode(array('success'=>0,'messages'=>$msgArr));
            die;
        }
        
        $connection = new DatabaseConnection;   
        // if(isset($_POST['department_status']) && (int)$_POST['department_status'] > 0){
        //     $department_status = 1;
        // } else {
        //     $department_status = 0;
        // }
         if($errors == 0){
            $connection->delete($table_name, array($primary_table_id_name => $primary_table_id_val));
            ///$connection->delete('roles_permissions', array('user_id' => $primary_table_id_val));
            $insertedId = $primary_table_id_val;
         }

        if(is_numeric($insertedId) && $insertedId > 0) {
            echo json_encode(array('success'=>1,'messages'=>array('Your request is successfully completed'),'table_name'=>$table_name));
            die;
        } else {
            echo json_encode(array('success'=>0,'messages'=>array('Could not delete in database')));
            die;
        }
    }
} catch(Exception $e){
    echo json_encode(array('success'=>0,'messages'=>array($e)));
            die;
}
?>