<?php
define('DB_SERVER','localhost');
define('DB_USER','woodmac');
define('DB_PASS' ,'123456');
define('DB_NAME', 'woodmac');

$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);

// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

define("PATH_ROOT", __DIR__);

function pre($data, $ex = null)
{
    echo '<pre>';
    print_r($data);
    echo '</pre>';
    if(!empty($ex))
    {
        exit;
    }
}

/*
Below class is used for interaction with db 
*/

class DatabaseConnection
{
    private $databaseHost = DB_SERVER;
    private $databaseUser = DB_USER;
    private $databasePass = DB_PASS;
    private $databaseName = DB_NAME;
    private $connection = false;
    private $result = array();
    private $myQuery = "";
    private $numResults = "";
    
    public function __construct()
    {
        self::connect();
    }
    
    private function connect()
    {
        if (!$this->connection) {
            $this->connection = mysqli_connect($this->databaseHost, $this->databaseUser, $this->databasePass, $this->databaseName);
            
            
            //mysqli_set_charset('utf8', $connected);
            if ($this->connection) {
                return true;
            } else {
                //array_push($this->result, mysql_error());
                return false;
            }
        } else {
            return true;
        }
    }
    
    /**
     *  @get all records
     *  @table, @rows = fields name, @join, @where, @order, @limit
     **/
    public function get($table, $rows = '*', $join = null, $where = null, $order = null, $limit = null,$defaultJoin="JOIN", $offset = 0)
    { 
        
       
        $selectQuery = 'SELECT ' . $rows . ' FROM ' . $table;
        if ($join != null) {
            $selectQuery .= ' '.$defaultJoin.' '. $join;
        }
        if ($where != null) {
            $selectQuery .= ' WHERE ' . $where;
        }
        if ($order != null) {
            $selectQuery .= ' ORDER BY ' . $order;
        }
        if ($limit != null) {
            if ($offset != '' || $offset == 0) {
                $selectQuery .= ' LIMIT '. $offset.','. $limit;
            } else {
                $selectQuery .= ' LIMIT ' . $limit;
            }
            
        }
        $this->myQuery = $selectQuery;

        $query         = $this->connection->query($selectQuery);
        $this->result = null;
        if ($query) {
            $this->numResults = mysqli_num_rows($query);
            for ($row = 0; $row < $this->numResults; $row++) {
                $result = mysqli_fetch_array($query);
                $keys   = array_keys($result);
                for ($key = 0; $key < count($keys); $key++) {
                    if (!is_int($keys[$key])) {
                        if (mysqli_num_rows($query) >= 1) {
                            $this->result[$row][$keys[$key]] = $result[$keys[$key]];
                        } else {
                            $this->result = null;
                        }
                    }
                }
            }
            return $this->result;
        } else {
            //array_push($this->result, mysql_error());
            return false;
        }
    }
    
    /**
     *  @get first record only
     *  @table, @rows = fields name, @join, @where, @order
     **/
    public function get_first($table, $rows = '*', $join = null, $where = null, $order = null)
    {
        
        $selectQuery = 'SELECT ' . $rows . ' FROM ' . $table;
        if ($join != null) {
            $selectQuery .= ' JOIN ' . $join;
        }
        if ($where != null) {
            $selectQuery .= ' WHERE ' . $where;
        }
        if ($order != null) {
            $selectQuery .= ' ORDER BY ' . $order;
        }
        $selectQuery .= ' LIMIT 1';
        
        $this->myQuery = $selectQuery;
        

        $query         = $this->connection->query($selectQuery);
        $this->result = null;
        if ($query) { 
            $this->numResults = mysqli_num_rows($query);
            for ($row = 0; $row < $this->numResults; $row++) {
                $result = mysqli_fetch_array($query);
                $keys   = array_keys($result);
                
                for ($key = 0; $key < count($keys); $key++) {
                    if (!is_int($keys[$key])) {
                        if (mysqli_num_rows($query) >= 1) {
                            $this->result[$keys[$key]] = $result[$keys[$key]];
                        } else {
                            $this->result = null;
                        }
                    }
                }
            }
            return $this->result;
        } else {
            //array_push($this->result, mysqli_error());
            return false;
        }
    }
    
    /**
    * @insert record
    **/
    public function insert($table, $params = array())
    {
        
        $params = $this->encode_htmlentities($params);

        //set default fields
        //$params = $this->create_default_fields($params, $params);
        
      
        $sqlQuery = 'INSERT INTO `' . $table . '` (`' . implode('`, `', array_keys($params)) . '`) VALUES ("' . implode('", "', $params) . '")';
    
        $this->myQuery = $sqlQuery;
        

        $id            = '';
        if ($this->connection->query($sqlQuery)) {
            $id = mysqli_insert_id($this->connection);
            return $id;
        } else {
            array_push($this->result, mysqli_error($this->connection));
            return false;
        }        
    }

    /**
    * @insert multiple records
    **/
    public function insertMany($table, $params = array(), $paramValues = array())
    {
        
        $valuesStr = '';
         

                  
        
        foreach($paramValues as $values){
            $values = $this->encode_htmlentities($values);

            $valuesStr.=  '("' . implode('", "', $values) . '"),';
        }
        $valuesStr = rtrim($valuesStr, ",");
        
        $sqlQuery = 'INSERT INTO `' . $table . '` (`' . implode('`, `', $params) . '`) VALUES '.$valuesStr;
        
        $this->myQuery = $sqlQuery;
        
        if ($this->connection->query($sqlQuery)) {
           
            return true;
        } else {
            //array_push($this->result, mysqli_error($this->connection));
            return false;
        }
    }
    

    /**
    * @Update records
    **/
    public function update($table, $params = array(), $where)
    {
        
        $args       = array();
        $where_args = array();
        
        //set default fields
        //$params = $this->update_default_fields($params);

        foreach ($params as $field => $value) {
            $args[] = $field . "='" . $value . "'";
        }
        
        foreach ($where as $field => $value) {
            $where_args[] = $field . '="' . $value . '"';
        }
        
        $sqlQuery = 'UPDATE ' . $table . ' SET ' . implode(',', $args) . ' WHERE ' . implode(' AND ', $where_args);
        
        $this->myQuery = $sqlQuery;
        
        if ($this->connection->query($sqlQuery)) {
            //array_push($this->result, mysql_affected_rows());
            return true;
        } else {
            array_push($this->result, mysqli_error($this->connection));
            return false;
        }
        
    }
    /*operators are for conditions like = in not in etc.*/
    public function delete($table, $where = null, $operators = null)
    {
        
        $where_args = array();
        
        $i = 0;
        foreach ($where as $field => $value) {
            if(isset($operators) && $operators != null){
                
                if(in_array($operators[$i], array('in', 'notin')))
                    $where_args[] = $field.' ' . $operators[$i] . ' ('.$value . ')';
                else 
                    $where_args[] = $field.' ' . $operators[$i] . ' "'.$value . '"';
            } else {
                $where_args[] = $field . '="' . $value . '"';
            }
            
            $i++;
        }
        
        $deleteQuery = 'DELETE FROM ' . $table . ' WHERE ' . implode(' AND ', $where_args);
        
        if ($this->connection->query($deleteQuery)) {
            //array_push($this->result, mysql_affected_rows());
            //$this->myQuery = $deleteQuery; 
            return true;
        } else {
            array_push($this->result, mysqli_error($this->connection));
            return false;
        }
    }
    
    public function getResult()
    {
        $value        = $this->result;
        $this->result = array();
        return $value;
    }

    /* get count of results from table*/
    public function getCount($table, $conditions = '', $join = null, $defaultJoin="JOIN")
    {
        
        if($conditions != ''){
            $conditions = ' where '.$conditions;
        }
        if ($join != null) {
            $selectQuery .= ' '.$defaultJoin.' '. $join;
        }
        $selectQuery = 'SELECT count(*) as num_records FROM ' . $table. $conditions;
        $this->myQuery = $selectQuery;
        
        
        $query         = $this->connection->query($selectQuery);
        if ($query) {
            $result = mysqli_fetch_assoc($query);            
            $num_of_records = $result['num_records'];
            return $num_of_records;
        } else {
            array_push($this->result, mysqli_error($this->connection));
            return false;
        }
       
    }
    
    /**
    * @Delete Multiple records from table
    **/
    public function deleteMany($table, $ids = array(),$columnname, $where = null)
    {
        global $LoggerOb;
        $multipleids  = array();
        $deleteQuery = 'DELETE FROM ' . $table;
        $whereStr = "";
        if(count($ids) > 0 && !empty($columnname))
        {
            $whereStr .= ' WHERE '. $columnname .' '.'in'.' '.'(' .implode(',', $ids).')';
        }
        if(!empty($where)) {
            if($whereStr == "") {
                $whereStr .= ' where ' . $where;
            } else {
                $whereStr .= ' AND ' . $where;
            }            
        }
        if($whereStr!= "") {
            $deleteQuery .=  $whereStr;
        }
        // pre($deleteQuery);
        // die;
        $LoggerOb->putLog($deleteQuery);
        if ($this->connection->query($deleteQuery)) {
            //array_push($this->result, mysql_affected_rows());
            //$this->myQuery = $deleteQuery; 
            return true;
        } else {
            array_push($this->result, mysqli_error($this->connection));
            return false;
        }
    }

    function encode_htmlentities($array) {
        $return_array = array();
        foreach($array as $key => $d) {
            if(is_string($d)) {
                $return_array[$key] = htmlentities($d);
            }else {
                $return_array[$key] = $d;
            }            
        }
        
        return $return_array; 
    }

    function getUserDetail($user_id){
        $uname = '';
        $user_data = $this->get_first('users', 'username', '', 'user_id  = ' . $user_id);
        if(!empty($user_data)){
            $uname = $user_data['username'];
        }
        return $uname;

    }

    function getPartyDetail($client_id){
        $pname = '';
        $party_data = $this->get_first('clients', 'party_name', '', 'client_id  = ' . $client_id);
        if(!empty($party_data)){
            $pname = $party_data['party_name'];
        }
        return $pname;

    }

    function machine_name($machine_id){
      $machine_name = $this->get_first('machines', 'machine_name', '', 'machine_id  = ' . $machine_id);
      return $machine_name['machine_name'];
    }
   

}
?>