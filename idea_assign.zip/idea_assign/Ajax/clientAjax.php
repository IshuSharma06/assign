<?php
session_start();
require_once("../include/config.php");
try {
    if(isset($_POST['action']) && $_POST['action'] == "client_form") {
        
        $data = $_POST;

        
        $uid = $_SESSION['id'];
        
        
       

        $party_name = "";
        $address  = "";
        $mobile_no = "";
        $email_id = "";
        $gstin = "";

        $errors = 0;
        $msgArr = array();

        if(!isset($_POST['party_name'])){
            $errors = $errors + 1;
            $msgArr[] = "Party name data is missing";
        } else if(isset($_POST['party_name']) && trim($_POST['party_name']) == ""){
            $errors = $errors + 1;
            $msgArr[] = "Please enter party name";
        } else {
            $party_name = $_POST['party_name'];
        }

        // if(!isset($_POST['mobile_no'])){
        //     $errors = $errors + 1;
        //     $msgArr[] = "Mobile Number data is missing";
        // } else if(isset($_POST['mobile_no']) && trim($_POST['mobile_no']) == ""){
        //     $errors = $errors + 1;
        //     $msgArr[] = "Please enter mobile number";
        // } else {
        //     $mobile_no = $_POST['mobile_no'];
        // }

        // if(!isset($_POST['email_id'])){
        //     $errors = $errors + 1;
        //     $msgArr[] = "Email Id data is missing";
        // } else if(isset($_POST['email_id']) && trim($_POST['email_id']) == ""){
        //     $errors = $errors + 1;
        //     $msgArr[] = "Please enter email Id";
        // } else {
        //     $email_id = $_POST['email_id'];
        // }

        // if(!isset($_POST['address'])){
        //     $errors = $errors + 1;
        //     $msgArr[] = "Address data is missing";
        // } else if(isset($_POST['address']) && trim($_POST['address']) == ""){
        //     $errors = $errors + 1;
        //     $msgArr[] = "Please enter address";
        // } else {
        //     $address = $_POST['address'];
        // }

        // if(!isset($_POST['gstin'])){
        //     $errors = $errors + 1;
        //     $msgArr[] = "Gstin data is missing";
        // } else if(isset($_POST['gstin']) && trim($_POST['gstin']) == ""){
        //     $errors = $errors + 1;
        //     $msgArr[] = "Please enter gstin";
        // } else {
        //     $gstin = $_POST['gstin'];
        // }

        if($errors > 0) {
            echo json_encode(array('success'=>0,'messages'=>$msgArr));
            die;
        }
        
        $connection = new DatabaseConnection;   
        // if(isset($_POST['department_status']) && (int)$_POST['department_status'] > 0){
        //     $department_status = 1;
        // } else {
        //     $department_status = 0;
        // }
         $date = date('Y-m-d H:i:s');

        $insertArr = array('party_name' => $data['party_name'],
                           'address'    => $data['address'],
                           'mobile_no'  => $data['mobile_no'],
                           'email_id' => $data['email_id'],
                           'description' => $_POST['description'],
                           'gstin' => $data['gstin'],
                           'status' => 'active',
                           'created_at' => $date
                        );
        // pre($insertArr);
        // die;



        

        if(isset($_POST['id']) && (int)$_POST['id'] > 0) {
            // $username_cond = 'mobile_no'. '="' . $mobile_no. '"'.' AND '.' '."client_id" .'!="' . $_POST['id'] . '"';
            // $users_count = $connection->getCount('clients', $username_cond);

               

                
            //     if($users_count > 0) {
            //         echo json_encode(array('success' => 0, 'messages' => array('Duplicate username not allowed')));
            //             die;
            //     }
            $connection->update('clients',$insertArr,array('client_id ' => $_POST['id']));
            /* Delete records from form inventory table and payment details table */
            $connection->delete('client_inventory', array('client_id' => $_POST['id']));
            $connection->delete('payment_details_inventory', array('client_id' => $_POST['id']));
                $insertArr = array();
                for($p=0;($p<count($data['purchase_year']));$p++){

                        if(!empty($data['purchase_year'][$p]) || !empty($data['machine_name'][$p]) || !empty($data['deal_price'][$p]) || !empty($data['gst_amount'][$p]) || !empty($data['freight_amount'][$p]) || !empty($data['total_amount'][$p]) || !empty($data['order_delivery_dt'][$p])){
                                $purchase_year = "";
                                $machine_name = "";
                                $deal_price = 0;
                                $gst_amount = 0;
                                $freight_amount = 0;
                                $total_amount = 0;
                                $order_delivery_dt = "";
                                $job_order_no = "";
                               

                                if(isset($data['purchase_year'][$p]) && trim($data['purchase_year'][$p]) !="") {
                                    $purchase_year = $data['purchase_year'][$p];

                                }
                                
                                if(isset($data['machine_name'][$p]) && trim($data['machine_name'][$p]) !="") {
                                    $machine_name = $data['machine_name'][$p];

                                }

                                if(isset($data['deal_price'][$p]) && (int)$data['deal_price'][$p] > 0) {
                                    $deal_price = $data['deal_price'][$p];
                                }

                                if(isset($data['gst_amount'][$p]) && (int)$data['gst_amount'][$p] > 0) {
                                    $gst_amount = $data['gst_amount'][$p];
                                }

                                if(isset($data['freight_amount'][$p]) && (int)$data['freight_amount'][$p] > 0) {
                                    $freight_amount = $data['freight_amount'][$p];
                                }

                                if(isset($data['total_amount'][$p]) && (int)$data['total_amount'][$p] > 0) {
                                    $total_amount = $data['total_amount'][$p];
                                }

                                

                                if(isset($data['order_delivery_dt'][$p]) && (int)$data['order_delivery_dt'][$p] > 0) {
                                    $order_delivery_dt = $data['order_delivery_dt'][$p];
                                }

                                if(isset($data['job_order_no'][$p]) && trim($data['job_order_no'][$p]) !="") {
                                    $job_order_no = $data['job_order_no'][$p];
                                }

                                
                                $insertArr = array('client_id' => $_POST['id'],
                                                       'purchase_year' =>$purchase_year,
                                                       'machine_name' => $machine_name,
                                                       'deal_price' => $deal_price,
                                                       'gst_amount' => $gst_amount,
                                                       'freight_amount' => $freight_amount,
                                                       'total_amount' => $total_amount,
                                                       'order_delivery_dt' => $order_delivery_dt,
                                                       'job_order_no' => $job_order_no,
                                                       'created_at'  => $date
                                                   );

                               

                                // if($purchase_year != "" && $machine_name != "" && $deal_price > 0 && $gst_amount > 0 && $freight_amount > 0 && $total_amount > 0 && $order_delivery_dt != ""){
                                //     // $insertArr[] = array();
                                //     $insertArr = array('client_id' => $insertedId,
                                //                        'purchase_year' =>$purchase_year,
                                //                        'machine_name' => $machine_name,
                                //                        'deal_price' => $deal_price,
                                //                        'gst_amount' => $gst_amount,
                                //                        'freight_amount' => $freight_amount,
                                //                        'total_amount' => $total_amount,
                                //                        'order_delivery_dt' => $order_delivery_dt,
                                //                        'created_at'  => $date
                                //                    );
                                // }
                                // pre($insertArr);
                                // die;
                                if(!empty($insertArr)){
                                    $insertedInventoryId = $connection->insert('client_inventory',$insertArr);
                                }
                                
                                $insertArr = array();
                                if(!empty($insertedInventoryId)){
                                    for($q=0;($q<count($data['payment_dt'][$p]));$q++){
                                        if(!empty($data['payment_dt'][$p][$q]) || !empty($data['type_of_payment'][$p][$q]) || !empty($data['mode_of_payment'][$p][$q]) || !empty($data['remarks'][$p][$q])){
                                            $payment_dt = "";
                                            $type_of_payment = "";
                                            $mode_of_payment = "";
                                            $remarks = "";
                                            // pre($data['payment_dt'][$q][$q]);
                                            // die;
                                            if(isset($data['payment_dt'][$p][$q]) && trim($data['payment_dt'][$p][$q]) !="") {
                                                $payment_dt = $data['payment_dt'][$p][$q];
                                            }
                                            if(isset($data['type_of_payment'][$p][$q]) && trim($data['type_of_payment'][$p][$q]) !="") {
                                                $type_of_payment = $data['type_of_payment'][$p][$q];
                                            }
                                            if(isset($data['mode_of_payment'][$p][$q]) && trim($data['mode_of_payment'][$p][$q]) !="") {
                                                $mode_of_payment = $data['mode_of_payment'][$p][$q];
                                            }
                                            if(isset($data['remarks'][$p][$q]) && trim($data['remarks'][$p][$q]) !="") {
                                                $remarks = $data['remarks'][$p][$q];
                                            }
                                            $insertArr[] = array('client_id' => $_POST['id'],
                                                        'inventory_id' => $insertedInventoryId,
                                                               'payment_dt' =>$payment_dt,
                                                               'type_of_payment' => $type_of_payment,
                                                               'mode_of_payment' => $mode_of_payment,
                                                               'remarks' => $remarks,
                                                               'created_at'  => $date
                                                           );
                                        }
                                    }
                                }
                                
                                
                                
                                 
                                
                               if(!empty($insertArr)){
                                        $connection->insertMany('payment_details_inventory', array('client_id','inventory_id', 'payment_dt','type_of_payment','mode_of_payment','remarks','created_at'), $insertArr);
                                }
                        }
                      
                    }

                    $notification_array = array('module' => 'Edit Payment Details',
                                                     'user_id' => $uid,
                                                     'notify_data' => json_encode('client_id:'.$_POST['id']),
                                                     'created_at' => $date
                                                );
                                    
                                   
                    if(!empty($notification_array) && !empty($insertArr)){
                        $connection->insert('notifications',$notification_array);
                    }   

                

            $insertedId = $_POST['id'];
        } else {
            $username_cond = 'mobile_no'. '="' . $mobile_no. '"';
            $users_count = $connection->getCount('clients', $username_cond);
            // pre($users_count);
            // die;
               

                
                if($users_count > 0) {
                    echo json_encode(array('success' => 0, 'messages' => '<span> Duplicate username not allowed</span> '));
                        die;
                }
                
                 $insertedId = $connection->insert('clients',$insertArr);
                 $insertArr = array();

                
                    // pre($data['deal_price']);
                    // die;

                    for($p=0;($p<count($data['purchase_year']));$p++){

                        if(!empty($data['purchase_year'][$p]) || !empty($data['machine_name'][$p]) || !empty($data['deal_price'][$p]) || !empty($data['gst_amount'][$p]) || !empty($data['freight_amount'][$p]) || !empty($data['total_amount'][$p]) || !empty($data['order_delivery_dt'][$p])){
                                $purchase_year = "";
                                $machine_name = "";
                                $deal_price = 0;
                                $gst_amount = 0;
                                $freight_amount = 0;
                                $total_amount = 0;
                                $order_delivery_dt = "";
                                $job_order_no = "";
                               

                                if(isset($data['purchase_year'][$p]) && trim($data['purchase_year'][$p]) !="") {
                                    $purchase_year = $data['purchase_year'][$p];

                                }
                                
                                if(isset($data['machine_name'][$p]) && trim($data['machine_name'][$p]) !="") {
                                    $machine_name = $data['machine_name'][$p];

                                }

                                if(isset($data['deal_price'][$p]) && (int)$data['deal_price'][$p] > 0) {
                                    $deal_price = $data['deal_price'][$p];
                                }

                                if(isset($data['gst_amount'][$p]) && (int)$data['gst_amount'][$p] > 0) {
                                    $gst_amount = $data['gst_amount'][$p];
                                }

                                if(isset($data['freight_amount'][$p]) && (int)$data['freight_amount'][$p] > 0) {
                                    $freight_amount = $data['freight_amount'][$p];
                                }

                                if(isset($data['total_amount'][$p]) && (int)$data['total_amount'][$p] > 0) {
                                    $total_amount = $data['total_amount'][$p];
                                }

                                

                                if(isset($data['order_delivery_dt'][$p]) && (int)$data['order_delivery_dt'][$p] > 0) {
                                    $order_delivery_dt = $data['order_delivery_dt'][$p];
                                }

                                if(isset($data['job_order_no'][$p]) && trim($data['job_order_no'][$p]) !="") {
                                    $job_order_no = $data['job_order_no'][$p];
                                }

                                $insertArr = array('client_id' => $insertedId,
                                                       'purchase_year' =>$purchase_year,
                                                       'machine_name' => $machine_name,
                                                       'deal_price' => $deal_price,
                                                       'gst_amount' => $gst_amount,
                                                       'freight_amount' => $freight_amount,
                                                       'total_amount' => $total_amount,
                                                       'order_delivery_dt' => $order_delivery_dt,
                                                       'job_order_no' => $job_order_no,
                                                       'created_at'  => $date
                                                   );

                               

                                // if($purchase_year != "" && $machine_name != "" && $deal_price > 0 && $gst_amount > 0 && $freight_amount > 0 && $total_amount > 0 && $order_delivery_dt != ""){
                                //     // $insertArr[] = array();
                                //     $insertArr = array('client_id' => $insertedId,
                                //                        'purchase_year' =>$purchase_year,
                                //                        'machine_name' => $machine_name,
                                //                        'deal_price' => $deal_price,
                                //                        'gst_amount' => $gst_amount,
                                //                        'freight_amount' => $freight_amount,
                                //                        'total_amount' => $total_amount,
                                //                        'order_delivery_dt' => $order_delivery_dt,
                                //                        'created_at'  => $date
                                //                    );
                                // }
                                // pre($insertArr);
                                // die;
                                if(!empty($insertArr)){
                                    $insertedInventoryId = $connection->insert('client_inventory',$insertArr);
                                }
                                
                                $insertArr = array();
                                if(!empty($insertedInventoryId)){
                                    for($q=0;($q<count($data['payment_dt'][$p]));$q++){
                                        if(!empty($data['payment_dt'][$p][$q]) || !empty($data['type_of_payment'][$p][$q]) || !empty($data['mode_of_payment'][$p][$q]) || !empty($data['remarks'][$p][$q])){
                                            $payment_dt = "";
                                            $type_of_payment = "";
                                            $mode_of_payment = "";
                                            $remarks = "";
                                            // pre($data['payment_dt'][$q][$q]);
                                            // die;
                                            if(isset($data['payment_dt'][$p][$q]) && trim($data['payment_dt'][$p][$q]) !="") {
                                                $payment_dt = $data['payment_dt'][$p][$q];
                                            }
                                            if(isset($data['type_of_payment'][$p][$q]) && trim($data['type_of_payment'][$p][$q]) !="") {
                                                $type_of_payment = $data['type_of_payment'][$p][$q];
                                            }
                                            if(isset($data['mode_of_payment'][$p][$q]) && trim($data['mode_of_payment'][$p][$q]) !="") {
                                                $mode_of_payment = $data['mode_of_payment'][$p][$q];
                                            }
                                            if(isset($data['remarks'][$p][$q]) && trim($data['remarks'][$p][$q]) !="") {
                                                $remarks = $data['remarks'][$p][$q];
                                            }
                                            $insertArr[] = array('client_id' => $insertedId,
                                                        'inventory_id' => $insertedInventoryId,
                                                               'payment_dt' =>$payment_dt,
                                                               'type_of_payment' => $type_of_payment,
                                                               'mode_of_payment' => $mode_of_payment,
                                                               'remarks' => $remarks,
                                                               'created_at'  => $date
                                                           );
                                        }
                                    }
                                }
                                
                                
                                
                                 
                                
                               if(!empty($insertArr)){
                                        $connection->insertMany('payment_details_inventory', array('client_id','inventory_id', 'payment_dt','type_of_payment','mode_of_payment','remarks','created_at'), $insertArr);
                                }
                        }
                      
                    }

                    $notification_array = array('module' => 'Add Payment Details',
                                                     'user_id' => $uid,
                                                     'notify_data' => json_encode('client_id:'.$insertedId),
                                                     'created_at' => $date
                                                );
                                    
                                   
                    if(!empty($notification_array) && !empty($insertArr)){
                        $connection->insert('notifications',$notification_array);
                    }   
                

                        
            }

                 
        

        if(is_numeric($insertedId) && $insertedId > 0) {
            $update = 0;
            if(isset($_POST['id']) && (int)$_POST['id'] > 0) {
                $update = 1;
                echo json_encode(array('success'=>1,'messages'=>'<span> Client data has been updated successfully</span> ','id'=>$insertedId,'update'=>$update));
            }else{
                echo json_encode(array('success'=>1,'messages'=>'<span> New client is successfully created</span> ','id'=>$insertedId,'update'=>$update));
            }
            
                
            die;
        } else {
            echo json_encode(array('success'=>0,'messages'=>array('Could not insert in database')));
            die;
        }
    }
} catch(Exception $e){
    echo json_encode(array('success'=>0,'messages'=>array($e)));
            die;
}
