<?php
session_start();
include('include/config.php');
if(strlen($_SESSION['alogin'])==0)
  { 
header('location:index.php');
}
else{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$currentTime = date( 'd-m-Y h:i:s A', time () ); 

$connection = new DatabaseConnection;

$clientData = array('machine_name' => '','party_name' => '', 'address' => '','mobile_no' => '', 'email_id' => '','description' => '','gstin' => '');
$machine_data = $connection->get('machines', '*', '' , '','machine_id ASC');
if(isset($_GET['cid']) && !empty($_GET['cid'])) {
$clientData = $connection->get_first('clients', 'party_name,address,mobile_no,email_id,description,gstin', '', 'client_id = ' . $_GET['cid']);
$client_inventory =  $connection->get('client_inventory', 'invent_id,purchase_year,machine_name,deal_price,gst_amount,freight_amount,total_amount,order_delivery_dt,client_id,job_order_no', '', 'client_id = ' . $_GET['cid']);

$payment_details = $connection->get('payment_details_inventory', 'client_id,inventory_id,payment_dt,type_of_payment,mode_of_payment', '', 'client_id = ' . $_GET['cid']);
// pre($payment_details);
// die;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin | Client Form</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <style>
    #response span {
      padding: 15px;
      color: red;
      font-size: 18px;
    }
  </style>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <?php require_once('include/navbar.php');?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php require_once('include/sidebar.php');?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
             <?php if(isset($_GET['cid']) && !empty($_GET['cid'])){?>
                 <h1>Edit Client</h1>
              <?php } else {?>
                 <h1>Add New Client</h1>
              <?php } ?>
          </div>
          <!-- <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Client Form</li>
            </ol>
          </div> -->
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <?php if(isset($_GET['cid']) && !empty($_GET['cid'])){?>
                 <h3 class="card-title">Edit Client</h3>
                <?php } else {?>
                 <h3 class="card-title">Add New Client</h3>
                <?php } ?>
                
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="Ajax/usersAjax.php" id="client_form" onsubmit="return validateUsersForm();" method="post">
                <input type="hidden" name="action" value="client_form">
                <?php if(isset($_GET['cid'])) {?>
                  <input type="hidden" name="id" value="<?php echo $_GET['cid']?>" />
                <?php } ?>
                <div class="card-body">
                  <div class="row">
                    <div class="col-6">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Party Name</label>
                        <input type="text" name="party_name" class="form-control" id="party_name" placeholder="Party Name" value="<?php echo $clientData['party_name']?>">
                        <span id="party_name_error" class="error invalid-feedback"></span>
                      </div>
                    </div>
                    <div class="col-6">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Party Address</label>
                        <input type="text" name="address" class="form-control" id="address" placeholder="Party Address" value="<?php echo $clientData['address']?>">
                        <span id="address_error" class="error invalid-feedback"></span>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-6">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Mobile Number</label>
                       <!--  <input type="text" name="mobile_no" class="form-control" id="mobile_no" placeholder=" Mobile Number" value="<?php echo $clientData['mobile_no']?>"> -->
                        <textarea name="mobile_no" class="form-control" id="mobile_no"><?php echo $clientData['mobile_no']?></textarea>
                        <span id="mobile_no_error" class="error invalid-feedback"></span>
                      </div>
                    </div>
                    <div class="col-6">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Email Id</label>
                        <input type="text" name="email_id" class="form-control" id="email_id" placeholder="Enter email" value="<?php echo $clientData['email_id']?>">
                        <span id="email_id_error" class="error invalid-feedback"></span>
                      </div>
                    </div>
                    
                  </div>
                  <div class="row">
                    <div class="col-6">
                      <div class="form-group">
                        <label for="exampleInputEmail1">GSTIN</label>
                        <input type="text" name="gstin" class="form-control" id="gstin" placeholder="Enter gstin" value="<?php echo $clientData['gstin']?>">
                        <span id="gstin_error" class="error invalid-feedback"></span>
                      </div>
                    </div>
                    <div class="col-6">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Description</label>
                        <textarea class="form-control" name="description" id="description" rows="3" placeholder="Enter ..."><?php echo $clientData['description']?></textarea>
                      </div>
                    </div>
                  </div>
                </div>
                <?php if(!isset($_GET['cid'])){?>
                <div class="card card-danger">
                  <div class="card-header">
                    <h3 class="card-title">Machines Data</h3>
                  </div>
                  <div class="card-body">
                    <div id="machine_section">
                      <div class="row machine">
                        <div class="col-xs-12 col-md-6">
                           <label for="exampleInputEmail1">Order Date</label>
                          <input type="date" class="form-control purchase_year" name="purchase_year[]">
                          <span class="error purchase_year_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Machine Name</label>
                          <!-- <input type="text" class="form-control machine_name" name="machine_name[]"> -->
                          <select name="machine_name[]" class="form-control machine_name">
                              <option value="">Please Select</option>
                              <?php 
                              foreach ($machine_data as $key => $value) {
                                
                              ?>
                              <option value="<?php echo $value['machine_id'];?>" <?php echo ($value['machine_id'] == $clientData['machine_name']) ? 'selected' : ''; ?>><?php echo $value['machine_name'];?></option>
                            <?php } ?>
                          </select>
                          <span class="error machine_name_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Deal Price</label>
                          <input type="text" id="deal_price1" class="form-control deal_price" name="deal_price[]">
                          <span class="error deal_price_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Gst Amount</label>
                          <!-- <input type="text" id="gst_amount1" class="form-control gst_amount" name="gst_amount[]" onkeyup="return calculateTotal('1')"> -->
                          <input type="text" id="gst_amount1" class="form-control gst_amount" name="gst_amount[]">
                          <span class="error gst_amount_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Freight Amount</label>
                          <!-- <input type="text" class="form-control freight_amount" name="freight_amount[]" id="freight_amount1" onkeyup="return calculateTotal('1')"> -->
                          <input type="text" class="form-control freight_amount" name="freight_amount[]" id="freight_amount1">
                          <span class="error freight_amount_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Total Amount</label>
                          <input type="text" id="total_amount1" class="form-control total_amount" name="total_amount[]" value="">
                          <span class="error total_amount_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Order Delivery Date</label>
                          <input type="date" class="form-control order_delivery_dt" name="order_delivery_dt[]">
                          <span class="error order_delivery_dt_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Job Order No</label>
                          <input type="text" class="form-control job_order_no" name="job_order_no[]">
                          <span class="error job_order_no_error invalid-feedback"></span>
                        </div>

                        <div id="payments0" class="payments">
                          <h3 class="mt-2 mb-2">Payment Details</h3>
                          <div class="row pay_section0">
                              <div class="col-xs-12 col-md-3 mt-1">
                                <label for="exampleInputEmail1">Payment Date</label>
                                <input type="date" class="form-control payment_dt" name="payment_dt[0][0]">
                                <span class="error payment_dt_error invalid-feedback"></span>
                              </div>
                              <div class="col-xs-12 col-md-3 mt-1">
                                <label for="exampleInputEmail1">Type Of Payment</label>
                                
                                <select class="form-control type_of_payment" name="type_of_payment[0][0]">
                                  <option value="">Please Select</option>
                                  <option value="advance_payment">Advance Payment</option>
                                  <option value="partial_payment">Partial Payment</option>
                                  <option value="final_payment">Final Payment</option>
                                </select>
                                <span class="error type_of_payment_error invalid-feedback"></span>
                              </div>
                              <div class="col-xs-12 col-md-2 mt-1">
                                <label for="exampleInputEmail1">Mode Of Payment</label>
                                
                                <select class="form-control mode_of_payment" name="mode_of_payment[0][0]">
                                  <option value="">Please Select</option>
                                  <option value="Cash">Cash</option>
                                  <option value="Bank">Bank</option>
                                </select>
                                <span class="error mode_of_payment_error invalid-feedback"></span>
                              </div>
                              <div class="col-xs-12 col-md-3 mt-1">
                                <label for="exampleInputEmail1">Remarks</label>
                                <textarea class="form-control remarks" name="remarks[0][0]"></textarea>
                                <span class="error remarks_error invalid-feedback"></span>
                              </div>
                          </div>
                        </div>
                        <!-- <a href="javascript:void(0);" class="mt-5" onclick="addmorepayment(0);">Add More Payments</a> --><br>
                      
                      <button type="button" class="btn btn-success"  onclick="addmorepayment(0);">Add More Payments</button>
                    </div>
                    </div><br>
                    
                    <button type="button" class="btn btn-success"  onclick="addmore();">Add More</button><br>
                  </div>
                </div>
              <?php } else if(isset($_GET['cid']) && !empty($client_inventory)){?>
                <div class="card card-danger">
                  <div class="card-header">
                    <h3 class="card-title">Machines Data</h3>
                  </div>
                  <div class="card-body">
                    <div id="machine_section">
                      <?php foreach ($client_inventory as $key => $value): ?>
                      <div class="row mt-3 border border-primary machine">
                        <div class="col-xs-12 col-md-6">
                           <label for="exampleInputEmail1">Order Date</label>
                          <input type="date" class="form-control purchase_year" name="purchase_year[]" value="<?php echo $value['purchase_year'];?>">
                          <span class="error purchase_year_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Machine Name</label>
                          
                          <select name="machine_name[]" class="form-control machine_name">
                              <option value="">Please Select</option>
                              <?php 
                              foreach ($machine_data as $key1 => $value1) {
                                
                              ?>
                              <option value="<?php echo $value1['machine_id'];?>" <?php echo ($value1['machine_id'] == $value['machine_name']) ? 'selected' : ''; ?>><?php echo $value1['machine_name'];?></option>
                            <?php } ?>
                          </select>
                          <span class="error machine_name_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1 mb-2">
                          <label for="exampleInputEmail1">Deal Price</label>
                          <input type="text" class="form-control deal_price" id="deal_price<?php echo $key;?>" name="deal_price[]" value="<?php echo $value['deal_price'];?>">
                          <span class="error deal_price_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Gst Amount</label>
                          <!-- <input type="text" id="gst_amount<?php echo $key;?>" class="form-control gst_amount" name="gst_amount[]" value="<?php echo $value['gst_amount'];?>" onkeyup="return calculateTotal('<?php echo $key;?>')"> -->
                          <input type="text" id="gst_amount<?php echo $key;?>" class="form-control gst_amount" name="gst_amount[]" value="<?php echo $value['gst_amount'];?>">
                          <span class="error gst_amount_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Freight Amount</label>
                          <!-- <input type="text" class="form-control freight_amount" name="freight_amount[]" id="freight_amount<?php echo $key;?>" value="<?php echo $value['freight_amount'];?>" onkeyup="return calculateTotal('<?php echo $key;?>')"> -->
                           <input type="text" class="form-control freight_amount" name="freight_amount[]" id="freight_amount<?php echo $key;?>" value="<?php echo $value['freight_amount'];?>">
                          <span class="error freight_amount_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Total Amount</label>
                          <input type="text" id="total_amount<?php echo $key;?>" class="form-control total_amount" name="total_amount[]" value="<?php echo $value['total_amount'];?>">
                          <span class="error total_amount_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1 mb-2">
                          <label for="exampleInputEmail1">Order Delivery Date</label>
                          <input type="date" class="form-control order_delivery_dt" name="order_delivery_dt[]" value="<?php echo $value['order_delivery_dt'];?>">
                          <span class="error order_delivery_dt_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Job Order No</label>
                          <input type="text" class="form-control job_order_no" name="job_order_no[]" value="<?php echo $value['job_order_no'];?>">
                          <span class="error job_order_no_error invalid-feedback"></span>
                        </div>
                        <div id="payments<?php echo $key?>" class="payments">
                          <h3 class="mt-2 mb-2">Payment Details</h3>
                          <?php
                          $payment_details_where = "client_id = '".$_GET['cid']."' AND inventory_id = '".$value['invent_id']."'"; 
                          $payment_details = $connection->get('payment_details_inventory', 'client_id,inventory_id,payment_dt,type_of_payment,mode_of_payment,remarks', '', $payment_details_where);
                          
                          $cnt = 0;
                          ?>
                          <?php if(!empty($payment_details)) {?>
                          <?php foreach ($payment_details as $paykey => $payvalue): ?>
                          <div class="row pay_section<?php echo $paykey;?>">
                              <div class="col-xs-12 col-md-2 mt-1">
                                <label for="exampleInputEmail1">Payment Date</label>
                                <input type="date" class="form-control payment_dt<?php echo $key;?>" name="payment_dt[<?php echo $key;?>][<?php echo $paykey?>]" value="<?php echo $payvalue['payment_dt'];?>">
                                <span class="error payment_dt_error invalid-feedback"></span>
                              </div>
                              <div class="col-xs-12 col-md-3 mt-1">
                                <label for="exampleInputEmail1">Type Of Payment</label>
                                
                                <select class="form-control type_of_payment<?php echo $key;?>" name="type_of_payment[<?php echo $key;?>][<?php echo $paykey?>]">
                                  <option value="">Please Select</option>
                                  <option value="advance_payment" <?php echo ($payvalue['type_of_payment'] == "advance_payment") ? 'selected' : ''; ?>>Advance Payment</option>
                                  <option value="partial_payment" <?php echo ($payvalue['type_of_payment'] == "partial_payment") ? 'selected' : ''; ?>>Partial Payment</option>
                                  <option value="final_payment" <?php echo ($payvalue['type_of_payment'] == "final_payment") ? 'selected' : ''; ?>>Final Payment</option>
                                </select>
                                <span class="error type_of_payment_error invalid-feedback"></span>
                              </div>
                              <div class="col-xs-12 col-md-3 mt-1">
                                <label for="exampleInputEmail1">Mode Of Payment</label>
                                
                                <select class="form-control mode_of_payment<?php echo $key;?>" name="mode_of_payment[<?php echo $key;?>][<?php echo $paykey?>]">
                                  <option value="">Please Select</option>
                                  <option value="Cash" <?php echo ($payvalue['mode_of_payment'] == "Cash") ? 'selected' : ''; ?>>Cash</option>
                                  <option value="Bank" <?php echo ($payvalue['mode_of_payment'] == "Bank") ? 'selected' : ''; ?>>Bank</option>
                                </select>
                                <span class="error mode_of_payment_error invalid-feedback"></span>
                              </div>
                              <div class="col-xs-12 col-md-3 mt-1">
                                <label for="exampleInputEmail1">Remarks</label>
                                <textarea class="form-control remarks<?php echo $key;?>" name="remarks[<?php echo $key;?>][<?php echo $paykey?>]"><?php echo $payvalue['remarks'];?></textarea>
                                <span class="error remarks_error invalid-feedback"></span>
                              </div>
                              <div class="col-1 mt-2"><label for="exampleInputEmail1"></label><a href="javascript:void(0);"><i class="fas fa-trash-alt removeIcon" ></i></a></div>

                          </div>
                          <?php endforeach ?>
                        <?php } else {?>
                            <div class="row pay_section0">
                                <div class="col-xs-12 col-md-3 mt-1">
                                  <label for="exampleInputEmail1">Payment Date</label>
                                  <input type="date" class="form-control payment_dt" name="payment_dt[0][0]">
                                  <span class="error payment_dt_error invalid-feedback"></span>
                                </div>
                                <div class="col-xs-12 col-md-3 mt-1">
                                  <label for="exampleInputEmail1">Type Of Payment</label>
                                  
                                  <select class="form-control type_of_payment" name="type_of_payment[0][0]">
                                    <option value="">Please Select</option>
                                    <option value="advance_payment">Advance Payment</option>
                                    <option value="partial_payment">Partial Payment</option>
                                    <option value="final_payment">Final Payment</option>
                                  </select>
                                  <span class="error type_of_payment_error invalid-feedback"></span>
                                </div>
                                <div class="col-xs-12 col-md-2 mt-1">
                                  <label for="exampleInputEmail1">Mode Of Payment</label>
                                  
                                  <select class="form-control mode_of_payment" name="mode_of_payment[0][0]">
                                    <option value="">Please Select</option>
                                    <option value="Cash">Cash</option>
                                    <option value="Bank">Bank</option>
                                  </select>
                                  <span class="error mode_of_payment_error invalid-feedback"></span>
                                </div>
                                <div class="col-xs-12 col-md-3 mt-1">
                                  <label for="exampleInputEmail1">Remarks</label>
                                  <textarea class="form-control remarks" name="remarks[0][0]"></textarea>
                                  <span class="error remarks_error invalid-feedback"></span>
                                </div>
                            </div>
                        <?php } ?>
                        </div>
                        <button type="button" class="btn btn-success"  onclick="addmorepaymentEdit(<?php echo $key?>);">Add More Payments</button>
                      </div>
                    
                      <?php endforeach ?>
                    </div><br>
                    <button type="button" class="btn btn-success"  onclick="addmore();">Add More</button>
                  </div>
                </div>
              <?php } else{?>
                <div class="card card-danger">
                  <div class="card-header">
                    <h3 class="card-title">Machines Data</h3>
                  </div>
                  <div class="card-body">
                    <div id="machine_section">
                      <div class="row machine">
                        <div class="col-xs-12 col-md-6">
                           <label for="exampleInputEmail1">Order Date</label>
                          <input type="date" class="form-control purchase_year" name="purchase_year[]">
                          <span class="error purchase_year_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Machine Name</label>
                          <!-- <input type="text" class="form-control machine_name" name="machine_name[]"> -->
                          <select name="machine_name[]" class="form-control machine_name">
                              <option value="">Please Select</option>
                              <?php 
                              foreach ($machine_data as $key => $value) {
                                
                              ?>
                              <option value="<?php echo $value['machine_id'];?>"><?php echo $value['machine_name'];?></option>
                            <?php } ?>
                          </select>
                          <span class="error machine_name_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Deal Price</label>
                          <input type="text" id="deal_price1" class="form-control deal_price" name="deal_price[]">
                          <span class="error deal_price_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Gst Amount</label>
                          <!-- <input type="text" id="gst_amount1" class="form-control gst_amount" name="gst_amount[]" onkeyup="return calculateTotal('1')"> -->
                          <input type="text" id="gst_amount1" class="form-control gst_amount" name="gst_amount[]">
                          <span class="error gst_amount_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Freight Amount</label>
                          <!-- <input type="text" class="form-control freight_amount" name="freight_amount[]" id="freight_amount1" onkeyup="return calculateTotal('1')"> -->
                          <input type="text" class="form-control freight_amount" name="freight_amount[]" id="freight_amount1">
                          <span class="error freight_amount_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Total Amount</label>
                          <input type="text" id="total_amount1" class="form-control total_amount" name="total_amount[]" value="">
                          <span class="error total_amount_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Order Delivery Date</label>
                          <input type="date" class="form-control order_delivery_dt" name="order_delivery_dt[]">
                          <span class="error order_delivery_dt_error invalid-feedback"></span>
                        </div>
                        <div class="col-xs-12 col-md-6 mt-1">
                          <label for="exampleInputEmail1">Job Order No</label>
                          <input type="text" class="form-control job_order_no" name="job_order_no[]">
                          <span class="error job_order_no_error invalid-feedback"></span>
                        </div>
                        <div id="payments0" class="payments">
                          <h3 class="mt-2 mb-2">Payment Details</h3>
                          <div class="row pay_section0">
                              <div class="col-xs-12 col-md-3 mt-1">
                                <label for="exampleInputEmail1">Payment Date</label>
                                <input type="date" class="form-control payment_dt" name="payment_dt[0][0]">
                                <span class="error payment_dt_error invalid-feedback"></span>
                              </div>
                              <div class="col-xs-12 col-md-3 mt-1">
                                <label for="exampleInputEmail1">Type Of Payment</label>
                                
                                <select class="form-control type_of_payment" name="type_of_payment[0][0]">
                                  <option value="">Please Select</option>
                                  <option value="advance_payment">Advance Payment</option>
                                  <option value="partial_payment">Partial Payment</option>
                                  <option value="final_payment">Final Payment</option>
                                </select>
                                <span class="error type_of_payment_error invalid-feedback"></span>
                              </div>
                              <div class="col-xs-12 col-md-2 mt-1">
                                <label for="exampleInputEmail1">Mode Of Payment</label>
                                
                                <select class="form-control mode_of_payment" name="mode_of_payment[0][0]">
                                  <option value="">Please Select</option>
                                  <option value="Cash">Cash</option>
                                  <option value="Bank">Bank</option>
                                </select>
                                <span class="error mode_of_payment_error invalid-feedback"></span>
                              </div>
                              <div class="col-xs-12 col-md-3 mt-1">
                                <label for="exampleInputEmail1">Remarks</label>
                                <textarea class="form-control remarks" name="remarks[0][0]"></textarea>
                                <span class="error remarks_error invalid-feedback"></span>
                              </div>
                          </div>
                        </div>
                        <!-- <a href="javascript:void(0);" class="mt-5" onclick="addmorepayment(0);">Add More Payments</a> --><br>
                      
                      <button type="button" class="btn btn-success"  onclick="addmorepayment(0);">Add More Payments</button>
                    </div>
                    </div><br>
                    
                    <button type="button" class="btn btn-success"  onclick="addmore();">Add More</button><br>
                  </div>
                </div>
              <?php } ?>
                <!-- /.card-body -->
                <div id="responseServerErrs"></div>
                <div id="response"></div>

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary float-right">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->

            

          </div>
          <!--/.col (left) -->
          <!-- right column -->
         
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php require_once('include/footer.php');?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>

<script src="dist/js/module/clients.js"></script>
<!-- Page specific script -->
<script>
$(function () {
  bsCustomFileInput.init();
});
</script>
</body>
</html>
<?php } ?>
