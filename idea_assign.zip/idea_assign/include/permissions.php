<?php 
require_once('config.php');
$quo_perm_data_p = array();
$quotation_permissions_where_p = "perm_mod = 'QUOT'";

$quotation_permissions_p = $connection->get('permissions', 'perm_mod,perm_id,perm_desc', '' , $quotation_permissions_where_p,'perm_id ASC');

foreach ($quotation_permissions_p as $key => $value) {
  // $quo_perm_data[] = array('perm_id'=>$value['perm_id'],'perm_desc'=>$value['perm_desc']);
  $quo_perm_data_p = array_column($quotation_permissions_p, 'perm_id', 'perm_desc');
 
}

$cli_perm_data_p = array();
$client_permissions_where_p = "perm_mod = 'CLIT'";

$client_permissions_p = $connection->get('permissions', 'perm_mod,perm_id,perm_desc', '' , $client_permissions_where_p,'perm_id ASC');
foreach ($client_permissions_p as $key => $value) {
  // $quo_perm_data[] = array('perm_id'=>$value['perm_id'],'perm_desc'=>$value['perm_desc']);
  $cli_perm_data_p = array_column($client_permissions_p, 'perm_id', 'perm_desc');
 
}

$trans_perm_data_p = array();
$transport_permissions_where_p = "perm_mod = 'TRANS'";

$transport_permissions_p = $connection->get('permissions', 'perm_mod,perm_id,perm_desc', '' , $transport_permissions_where_p,'perm_id ASC');
foreach ($transport_permissions_p as $key => $value) {
  // $quo_perm_data[] = array('perm_id'=>$value['perm_id'],'perm_desc'=>$value['perm_desc']);
  $trans_perm_data_p = array_column($transport_permissions_p, 'perm_id', 'perm_desc');
 
}
if(isset($_SESSION['id']) && !empty($_SESSION['id'])){
  
    $quot_roles_perm_data_p = array();
    $quotation_roles_permissions_where_p = "user_id = '".$_SESSION['id']."' AND perm_mod = 'QUOT'"; 
    $quote_role_permissions_p = $connection->get('roles_permissions', 'role_id,perm_id,perm_mod,user_id', '', $quotation_roles_permissions_where_p);
    if(!empty($quote_role_permissions_p)){
      foreach ($quote_role_permissions_p as $key => $value) {
        $quot_roles_perm_data_p = array_column($quote_role_permissions_p, 'perm_id');
      }
     
    }
// pre($quot_roles_perm_data);
// die;
    $client_roles_perm_data_p = array();
    $client_roles_permissions_where_p = "user_id = '".$_SESSION['id']."' AND perm_mod = 'CLIT'"; 
    $client_role_permissions_p = $connection->get('roles_permissions', 'role_id,perm_mod,perm_id,user_id', '', $client_roles_permissions_where_p);

    if(!empty($client_role_permissions_p)){
      foreach ($client_role_permissions_p as $key => $value) {
        $client_roles_perm_data_p = array_column($client_role_permissions_p, 'perm_id');
      }
     
    }

    $transport_roles_perm_data_p = array();
    $transport_roles_permissions_where_p = "user_id = '".$_SESSION['id']."' AND perm_mod = 'TRANS'"; 
    $transport_role_permissions_p = $connection->get('roles_permissions', 'role_id,perm_mod,perm_id,user_id', '', $transport_roles_permissions_where_p);
    //pre($transport_role_permissions);

    if(!empty($transport_role_permissions_p)){
      foreach ($transport_role_permissions_p as $key => $value) {
        $transport_roles_perm_data_p = array_column($transport_role_permissions_p, 'perm_id');
      }
     
    }

    $fitting_roles_perm_data_p = array();
    $fitting_roles_permissions_where_p = "user_id = '".$_SESSION['id']."' AND perm_mod = 'FITT'"; 
    $fitting_role_permissions_p = $connection->get('roles_permissions', 'role_id,perm_mod,perm_id,user_id', '', $fitting_roles_permissions_where_p);
    //pre($transport_role_permissions);

    if(!empty($fitting_role_permissions_p)){
      foreach ($fitting_role_permissions_p as $key => $value) {
        $fitting_roles_perm_data_p = array_column($fitting_role_permissions_p, 'perm_id');
      }
     
    }

    $allpermissions = array();
    $permissions = $connection->get('permissions', 'perm_mod,perm_id,perm_desc', '' , '','perm_id ASC');

	foreach ($permissions as $key => $value) {
	  // $quo_perm_data[] = array('perm_id'=>$value['perm_id'],'perm_desc'=>$value['perm_desc']);
	  $allpermissions = array_column($permissions, 'perm_id', 'perm_desc');
	 
	}
	// pre($allpermissions).'<br>';
	// pre($client_roles_perm_data_p).'<br>';
 //  die;

	$GLOBALS['quotmodule'] = 0;
	$GLOBALS['quotAdd_p'] = 0;
	$GLOBALS['quotView_p'] = 0;
	$GLOBALS['quotEdit_p'] = 0;
	$GLOBALS['quotDelete_p'] = 0;

  if(!empty($quot_roles_perm_data_p)){
    $GLOBALS['quotmodule'] = 1;
  }
	foreach ($quot_roles_perm_data_p as $key => $value) {
		if(in_array($allpermissions['Add new quotation'], $quot_roles_perm_data_p)){
			$GLOBALS['quotAdd_p'] = 1;
		}
	}
  foreach ($quot_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Update quotation'], $quot_roles_perm_data_p)){
      $GLOBALS['quotEdit_p'] = 1;
    }
  }
  foreach ($quot_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Delete quotation'], $quot_roles_perm_data_p)){
      $GLOBALS['quotDelete_p'] = 1;
    }
  }
  foreach ($quot_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['View quotation'], $quot_roles_perm_data_p)){
      $GLOBALS['quotView_p'] = 1;
    }
  }

  $GLOBALS['clientmodule'] = 0;
  $GLOBALS['clientAdd_p'] = 0;
  $GLOBALS['clientView_p'] = 0;
  $GLOBALS['clientEdit_p'] = 0;
  $GLOBALS['clientDelete_p'] = 0;

  if(!empty($client_roles_perm_data_p)){
    $GLOBALS['clientmodule'] = 1;
  }
  foreach ($client_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Add new client'], $client_roles_perm_data_p)){
      $GLOBALS['clientAdd_p'] = 1;
    }
  }
  foreach ($client_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Update client'], $client_roles_perm_data_p)){
      $GLOBALS['clientEdit_p'] = 1;
    }
  }
  foreach ($client_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Delete client'], $client_roles_perm_data_p)){
      $GLOBALS['clientDelete_p'] = 1;
    }
  }
  foreach ($client_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['View client'], $client_roles_perm_data_p)){
      $GLOBALS['clientView_p'] = 1;
    }
  }

  $GLOBALS['transportmodule'] = 0;
  $GLOBALS['transportAdd_p'] = 0;
  $GLOBALS['transportView_p'] = 0;
  $GLOBALS['transportEdit_p'] = 0;
  $GLOBALS['transportDelete_p'] = 0;

  if(!empty($transport_roles_perm_data_p)){
    $GLOBALS['transportmodule'] = 1;
  }
  foreach ($transport_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Add new transport'], $transport_roles_perm_data_p)){
      $GLOBALS['transportAdd_p'] = 1;
    }
  }
  foreach ($transport_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Update transport'], $transport_roles_perm_data_p)){
      $GLOBALS['transportEdit_p'] = 1;
    }
  }
  foreach ($transport_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Delete transport'], $transport_roles_perm_data_p)){
      $GLOBALS['transportDelete_p'] = 1;
    }
  }
  foreach ($transport_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['View transport'], $transport_roles_perm_data_p)){
      $GLOBALS['transportView_p'] = 1;
    }
  }
	// pre($quotAdd_p);
	// die;

  $GLOBALS['fittingmodule'] = 0;
  $GLOBALS['fittingAdd_p'] = 0;
  $GLOBALS['fittingView_p'] = 0;
  $GLOBALS['fittingEdit_p'] = 0;
  $GLOBALS['fittingDelete_p'] = 0;

  if(!empty($fitting_roles_perm_data_p)){
    $GLOBALS['fittingmodule'] = 1;
  }
  foreach ($fitting_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Add new fitting'], $fitting_roles_perm_data_p)){
      $GLOBALS['fittingAdd_p'] = 1;
    }
  }
  foreach ($fitting_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Update fitting'], $fitting_roles_perm_data_p)){
      $GLOBALS['fittingEdit_p'] = 1;
    }
  }
  foreach ($fitting_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['Delete fitting'], $fitting_roles_perm_data_p)){
      $GLOBALS['fittingDelete_p'] = 1;
    }
  }
  foreach ($fitting_roles_perm_data_p as $key => $value) {
    if(in_array($allpermissions['View fitting'], $fitting_roles_perm_data_p)){
      $GLOBALS['fittingView_p'] = 1;
    }
  }


}
?>