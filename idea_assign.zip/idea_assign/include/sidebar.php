<?php require_once('permissions.php');
// pre($_SESSION);
// die;


?>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
     Admin
     
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <!-- <div class="image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div> -->
        <div class="info">
          <?php if(isset($_SESSION['type']) && $_SESSION['type'] == 'admin'){?>
          <a href="#" class="d-block" style="margin-left: 10px;"><i class="fas fa-user space-icon"></i>Welcome Admin</a>
        <?php }  ?>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      <!-- <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div> -->

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item menu-open">
            <a href="dashboard.php" class="nav-link active">Dashboard</a>
          </li>
        <?php if(isset($_SESSION['type']) && $_SESSION['type'] == 'admin'){?>
          
         
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="fas fa-user-friends space-icon"></i>
              <p class="text-start">
                Clients Management
                <i class="fas fa-angle-left right"></i>
                <!-- <span class="badge badge-info right">6</span> -->
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="viewclients.php" class="nav-link">
                  <i class="fas fa-eye nav-icon"></i>
                  <p>View Clients</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="client_form.php" class="nav-link">
                  <i class="fas fa-plus nav-icon"></i>
                  <p>Add Clients</p>
                </a>
              </li>
            </ul>
          </li>
         
           
          
        <?php } ?>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>